function [BeRST] = BeDominatedCount(A,ObjArray,index,PopNum,ObjNum)
     RST = 0;
     ObjSingle = A;
     for i = 1:PopNum
         if i == index
             continue;
         end
         DomCount =0;
         LessThan =0;
         for j = 1:ObjNum
             if ObjSingle(j) >= ObjArray(i,j)
                 DomCount = DomCount+1;
             end
             if ObjSingle(j) > ObjArray(i,j)
                 LessThan = LessThan+1;
             end
         end
         if (DomCount == ObjNum) && (LessThan>0)
             RST = RST +1;
         end
     end
     BeRST = RST;