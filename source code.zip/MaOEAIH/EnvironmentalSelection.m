function [Population,EN,EN1]= EnvironmentalSelection(Population,N,M)
% The environmental selection of NSGA-IIes

%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
    %% Non-dominated sorting
    [FrontNo,MaxFNo] = NDSort(Population.objs,Population.cons,N);
    Next = FrontNo < MaxFNo;
    %% Select the solutions in the last front based on their MED
    Last = find(FrontNo==MaxFNo);
    P=sum(Next);
    K=N-P;
    [~,Last_len] = size(Last);
    [~,NextLen] = size(Next);
    record_last = ones(1,Last_len);
    ObjArray = Population.objs;
    Menr=zeros(NextLen,NextLen);
    Menr=EEnergy1(ObjArray,Menr);
    for i=1:K
        EEN=zeros(1,Last_len);
        EEN(1,:)=-1;
        for j=1:Last_len
            if Next(Last(j))==true
                continue;
            end
            Next(Last(j))=true;
            EEN(j)=sum(sum(Menr(Next,Next)))*(sum(sum(ObjArray(Next,:))));
            Next(Last(j))=false;
        end
        mine=inf;
        h=-1;
        for t=1:Last_len
            if (mine>=EEN(t))&&(EEN(t)>=0)
                mine=EEN(t);
                h=t;
            end
        end
        Next(Last(h))=true;
        record_last(h)=0;
    end
%      x=0;
%     for i=1:N
%         if FrontNo(i)==1
%             x=x+1;
%         else
%             break;
%         end
%     end
%     newe=(sum(sum(Menr(Next,Next))));
%     if x==N
%         oldp=Next;
%         oldp(1:NextLen)=false;
%         oldp(1:N)=true;
%         olde=(sum(sum(Menr(oldp,oldp))));
%         if olde<newe
%             newe=olde;
%             Next=oldp;
%             x=x+1;
%         end
%     end
%     if x==(N+1)
%        SelectLast=Last(1:N);
%        UndeterLast=Last(N+1:Last_len);
%     else
       SelectLast=Last(~record_last);
       UndeterLast=Last(~(~record_last));
%     end
    b=sum(Next);
%     SelectLast=Last(~record_last);
%     UndeterLast=Last(~(~record_last));
    [~,Len1]=size(SelectLast);
    [~,Len2]=size(UndeterLast);
    for j=1:Len1
        NewEEN=ones(1,Len2);
        for l=1:Len2
            NewNext=Next;
            NewNext(SelectLast(j))=false;
            NewNext(UndeterLast(l))=true;
            nMenr=Menr(NewNext,NewNext);
            NewEEN(l)=sum(sum(nMenr))*(sum(sum(ObjArray(NewNext,:))));
        end
        [MinNewEEN,l]=min(NewEEN);
        oMenr=Menr(Next,Next);
        OldEEN=sum(sum(oMenr))*(sum(sum(ObjArray(Next,:))));
        if MinNewEEN<OldEEN
            Next(SelectLast(j))=false;
            Next(UndeterLast(l))=true;
            temp=SelectLast(j);
            SelectLast(j)=UndeterLast(l);
            UndeterLast(l)=temp;
        end
    end
   %% Population for next generation
    Population = Population(Next);
    EN=sum(sum(Menr(Next,Next)))*(sum(sum(ObjArray(Next,:))));
    EN1=(sum(sum(ObjArray(Next,:))));
    