function [isDom] = IsDominate(A,B,ObjNum)
  DomCount =0; 
  LessThan =0;
  ObjA =A;
  ObjB =B;
  for i = 1:ObjNum
      if ObjA(i) <= ObjB(i)
          DomCount = DomCount+1;
      end
      if ObjA(i) < ObjB(i)
          LessThan = LessThan+1;
      end
  end
  if (DomCount ==ObjNum)&&(LessThan>0)
      isDom = true;
  else
      isDom = false;
  end