 function [IQR] = Preprocessing(new_Zu,n,IFIQR,maxbor)
     obj=new_Zu;
     new_Zu(n+1,:)= IFIQR;
     pnew_Zu=new_Zu;
     [x,m]=size(pnew_Zu);
     tiqr=pnew_Zu(n+1,:);
     a=sum(pnew_Zu');
     pnew_Zu=sort(a,'ascend');
     UB=inf;
     k=0;
     if x>=4
         Q1=pnew_Zu(floor(x/4))*(1-(x/4-floor(x/4)))+pnew_Zu(floor(x/4)+1)*(x/4-floor(x/4));
         Q3=pnew_Zu(floor(3*x/4))*(1-(3*x/4-floor(3*x/4)))+pnew_Zu(floor(3*x/4)+1)*(3*x/4-floor(3*x/4));
         UB=Q3+1.5*(Q3-Q1);
     end

     c=(tiqr>(diag(maxbor))');
     b=max(sum(maxbor'));
     d=(b>UB);
     if d==true
         UB=b;
     end
     if sum(tiqr)<= UB
         R=true;
     else
         R=false;
     end
     if R
         IQR=true;
     else
         IQR=false;
     end 
     
%      c=max(tiqr)<=max(maxbor);

