% function Menr = EEnergy(ObjArray,Menr)
%      Z =ObjArray;
%      [N,M] = size(Z);
%      s=M-1;
%      for i = 1:N
%          u1=0;
%          for j = 1:N
%              u2=0;
%              if i==j
%                  continue;
%              end
%              for l =1:M
%                  u2=u2+(Z(i,l)-Z(j,l))^2;%abs((Z(i,l)-Z(j,l))^s);
%              end
% %              u2 = (acos(dot(Z(i,:),Z(j,:))/(norm(Z(i,:))*norm(Z(j,:)))))^s;
%              Menr(i,j)=1/(sqrt(u2))^s;
%              u1=1/u2+u1; 
%          end
%      end
function Menr = EEnergy(ObjArray,Menr)
     Z =ObjArray;
     [N,M] = size(Z);
     s=M-1;
     for i = 1:N
         u1=0;
         for j = 1:N
             u2=0;
             if i==j
                 continue;
             end
%              for l =1:M
%                  u2=u2+(Z(i,l)-Z(j,l))^2;%abs((Z(i,l)-Z(j,l))^s);
%              end
%              u2 = (acos(dot(Z(i,:),Z(j,:))/(norm(Z(i,:))*norm(Z(j,:)))));
%              u3=0;
%              u4=0;
%              for l =1:M
%                  u3=u3+Z(i,l)^2;%abs((Z(i,l)-Z(j,l))^s);
%                  u4=u4+Z(j,l)^2;
%              end
%              u2=pdist2(Z(i,:),Z(j,:),'cosine')^2/(u3*u4);
%              Menr(i,j)=1/abs(sqrt(u2))^s;
%              u1=1/abs(sqrt(u2))^s+u1; 
             for l =1:M
                 u2=u2+abs(Z(i,l)-Z(j,l));%abs((Z(i,l)-Z(j,l))^s);
             end
             Menr(i,j)=1/u2^s;
         end
     end