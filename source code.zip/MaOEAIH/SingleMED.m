function [MED] = SingleMED(A)
   [N,~]=size(A);
   MED=zeros(1,N);
   MED(:)=inf;
   for j=1:N
     MinCos=zeros(1,N);
     MinCos(:)=inf;
     for i = 1:N
        if j==i
         continue;
        end
        MinCos(i) =acos(dot(A(i,:),A(j,:))/(norm(A(i,:))*norm(A(j,:)))); %pdist2(A(j,:),A(i,:),'cosine');
     end
     MED(j) = min(MinCos);
   end