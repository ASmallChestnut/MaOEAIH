classdef MaOEAIH < ALGORITHM
% <multi/many> <real/binary/permutation>
% A many-objective evolutionary algorithm based on interaction force and hybrid optimization mechanism
% type --- 4 --- The type of aggregation function
% status1   ---   100 --- status1
% status2 --- 20 --- status2
% status3  ---    60 --- status3

%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            [type,status1,status2,status3] = Algorithm.ParameterSet(4,100,20,60);
            %% Generate random population
            Population = Problem.Initialization();
            oldEN=inf;
            EN=inf;
            his=ones(Problem.M,Problem.M);
            u=0;
            t=0;
            pu=0;
            uuuu=0;
            uu=0;
            pu1=0;
            uuu=0;
            sumop=inf;
            %% Optimization
            maxM=zeros(1,Problem.M);
            while Algorithm.NotTerminated(Population)
                % For each solution
                                     
%                      EN1
               if u==0   
                if EN<oldEN||oldEN==inf
                   oldEN=EN;
                   t=0;
                else
                    t=t+1;
                end
                
                if t>=status1
                    if pu==1
                        u=1;
                    end
                    pu=1;
                    oldEN=inf;
                    t=0;
                end
               end
                if u==0|| uu==1&&uuu==0
                    if u==0
                    Offspring=[];
                    MatingPool = TournamentSelection(2,Problem.N,sum(max(0,Population.cons),2));
                    if pu==1
                        for qq=1:Problem.N
                               r=randi([1,2]);
                               if r==1
                                   r1=randi([1,Problem.N]);
                                   r2=randi([1,Problem.N]);
                                   Offspring = [Offspring,OperatorGAhalf1([Population(r1),Population(r2)])];
                               else
                                   r1=randi([1,Problem.N]);
                                   r2=randi([1,Problem.N]);
                                   Offspring = [Offspring,OperatorGAhalf([Population(r1),Population(r2)])];
                               end
                        end
                    else
                        Offspring  = OperatorGA(Population(MatingPool));
                    end
                    [Population,EN,EN1] = EnvironmentalSelection([Population,Offspring],Problem.N,Problem.M);
                

                    else
                        [Population,IFENN]= WVctor(Population,maxM,Problem.N,Problem.M,his,pu1);
                        if IFENN<oldEN||oldEN==inf
                           oldEN=IFENN;
                           t=0;            
                        else
                            t=t+1;
                        end
                        
                        if t>=status3
                            if pu1==1
                                uuu=1;
                            end
                            pu1=1;
                            oldEN=inf;
                            t=0;
                            uuuu=0;
                        end
                   end
       
                 %% Generate the weight vectors
                    W=Population.objs;
                    for i=1:Problem.N
                        W(i,:) =  1*W(i,:)/(norm(W(i,:)));
                    end
%                     W = unitObj(W);
                    T = ceil(Problem.N/10);
                 %% Detect the neighbours of each solution
                    B = pdist2(W,W);
                    [~,B] = sort(B,2);
                    B = B(:,1:T);
%                     Z = min(Population.objs,[],1);
                    Z = zeros(1,Problem.M);
                end
                if (u==1&&uu==0)||uuu==1
                    for i = 1 : Problem.N
                        % Choose the parents
                        P = B(i,randperm(size(B,2)));

                        % Generate an offspring
                         if uuuu==1
                           r=randi([1,2]);
                           if r==1
                               Offspring = OperatorGAhalf1(Population(P(1:2)));
                           else
                               Offspring = OperatorGAhalf(Population(P(1:2)));
                           end
                           
                         else       
                            Offspring = OperatorGAhalf(Population(P(1:2)));
                         end

                        % Update the ideal point
%                          Z = min(Z,Offspring.obj);

                        % Update the neighbours
                        switch type
                            case 1
                                % PBI approach
                                normW   = sqrt(sum(W(P,:).^2,2));
                                normP   = sqrt(sum((Population(P).objs-repmat(Z,T,1)).^2,2));
                                normO   = sqrt(sum((Offspring.obj-Z).^2,2));
                                CosineP = sum((Population(P).objs-repmat(Z,T,1)).*W(P,:),2)./normW./normP;
                                CosineO = sum(repmat(Offspring.obj-Z,T,1).*W(P,:),2)./normW./normO;
                                g_old   = normP.*CosineP + 5*normP.*sqrt(1-CosineP.^2);
                                g_new   = normO.*CosineO + 5*normO.*sqrt(1-CosineO.^2);
                            case 2
                                % Tchebycheff approach
                                g_old = max(abs(Population(P).objs-repmat(Z,T,1)).*W(P,:),[],2);
                                g_new = max(repmat(abs(Offspring.obj-Z),T,1).*W(P,:),[],2);
                            case 3
                                % Tchebycheff approach with normalization
                                Zmax  = max(Population.objs,[],1);
                                g_old = max(abs(Population(P).objs-repmat(Z,T,1))./repmat(Zmax-Z,T,1).*W(P,:),[],2);
                                g_new = max(repmat(abs(Offspring.obj-Z)./(Zmax-Z),T,1).*W(P,:),[],2);
                            case 4
                                % Modified Tchebycheff approach
                                g_old = max(abs(Population(P).objs-repmat(Z,T,1))./W(P,:),[],2);
                                g_new = max(repmat(abs(Offspring.obj-Z),T,1)./W(P,:),[],2);
                        end
                        Population(P(g_old>=g_new)) = Offspring;
                    end
                    sum(sum(Population.objs))-sumop
                        if sum(sum(Population.objs))<sumop+0.000001

                                t=0;
                                sumop=sum(sum(Population.objs));

                            
                        else
                           t=t+1;
                        end
                        
                       
           
                        if t>=status2
                            if uuuu==1
                                uu=1;
                            end
                            uuuu=1;
                            sumop=inf;
                            t=0;
                        end
                    
                    if uu==1&&uuu==0
                        
                        M=Problem.M;
                        maxM=Population.objs;
                        ObjArray = Population.objs;
                        [No,~]=size(ObjArray);
                        W1=zeros(M,M);
                        for i=1:M
                            W1(i,i)=1;
                        end
                        for i=1:M
                            ww1=inf;
                            ww1s=inf;
                            wt=1;
                            for j=1:No
                               ww=pdist2(W1(i,:),ObjArray(j,:),'cosine');
                               wws=sum(ObjArray(j,:));
                               if ww1>=ww
                                  if ww1==ww
                                     if wws<ww1s
                                         ww1=ww;
                                         wt=j;
                                     end
                                  else
                                      ww1=ww;
                                      wt=j;
                                  end
                               end
                            end
                            his(i,:)=ObjArray(wt,:);
                        end
                    end
                    
                end
                 
            end
        end
    end
end