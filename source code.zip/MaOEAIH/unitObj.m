function [ObjArray] = unitObj(ObjArray)
    [PopNum,ObjNum]=size(ObjArray);
    Zd=zeros(1,ObjNum);
    Zn=zeros(1,ObjNum);
    for i=1:ObjNum
        Zd(i)=min(ObjArray(:,i));
        Zn(i)=max(ObjArray(:,i));
    end
    for i=1:PopNum
        for j=1:ObjNum
            ObjArray(i,j)=(ObjArray(i,j)-Zd(j))/(Zn(j)-Zd(j));
        end
    end
    
