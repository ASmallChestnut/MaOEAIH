function [Population,IFENN]= WVctor(SW,maxM,N,M,his,pu1)
           Next=ones(1,2*N);
           Next=logical(Next);
           Next(N+1:2*N)=false;
           OBJ=SW.objs;
  
           ifk=ones(1,N);
           Offspring=[];
           for i =1:N
% 
               r=randi([1,2]);
               if r==1&&pu1==1
                  
                   r2=randi([1,N]);
                   Offspring = [Offspring,OperatorGAhalf1([SW(i),SW(r2)])];
               else
                  
                   r2=randi([1,N]);
                   Offspring = [Offspring,OperatorGAhalf([SW(i),SW(r2)])];
               end


           end
           FBJ=Offspring.objs;
           nof=ones(1,N);
          
           for j=1:N
               iqr=Preprocessing( maxM,N, FBJ(j,:),his);
               if iqr==false
                  nof(j)=0;
               end
           end

           for j=1:N
              iqr=Preprocessing( maxM,N, OBJ(j,:),his);
               if iqr==false
                  ifk(j)=0;
               end
           end
           Menr=zeros(2*N,2*N);
           ObjArray=[OBJ;FBJ];
%            ObjArray=unitObj(ObjArray);
           Menr=EEnergy(ObjArray,Menr);
           for t =1:N
                if nof(t)==0
                    continue;
                end
                NewCandidate=FBJ(t,:);
                OldCandidate=SW(t).objs;
                if IsDominate(NewCandidate,OldCandidate,M)
                   Next(t)=false;
                   Next(N+t)=true;
%                    ifz1=1;
%                        kw(index,:)=newdecs;
                elseif IsDominate(OldCandidate,NewCandidate,M)
                   
                    continue; 
                else 
                        OldBeDom = BeDominatedCount(OldCandidate,OBJ,t,N,M);
%                         OldDist = SingleMED(OldCandidate,index,SW,ObjNum,PopNum,con,Slen);
                        NewBeDom = BeDominatedCount(NewCandidate,OBJ,t,N,M);
%                         NewDist = SingleMED(NewCandidate,index,SW,ObjNum,PopNum,con,Slen);
                    if OldBeDom == NewBeDom
                            OldENN=sum(sum(Menr(Next,Next)));
                            Next(t)=false;
                            Next(N+t)=true;
                            NewENN=sum(sum(Menr(Next,Next)));
                            Next(t)=true;
                            Next(N+t)=false;
                            if  NewENN < OldENN||ifk(t)==0
                                Next(t)=false;
                                Next(N+t)=true;
                            else
                                continue;
                              
                            end
                     elseif OldBeDom > NewBeDom
                             Next(t)=false;
                             Next(N+t)=true;
                    else
                        continue;
                
                    end
                end 
    %          end
           end
    aaa=Menr(Next,Next);
    IFENN=sum(sum(aaa));
    Pop=[SW,Offspring];
    Population=Pop(Next);
%     IFENN=sum(sum(Population.objs));
